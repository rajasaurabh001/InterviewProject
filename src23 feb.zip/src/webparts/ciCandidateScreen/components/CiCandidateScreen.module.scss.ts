/* tslint:disable */
require("./CiCandidateScreen.module.css");
const styles = {
  ciCandidateScreen: 'ciCandidateScreen_b8f83ee9',
  teams: 'teams_b8f83ee9',
  welcome: 'welcome_b8f83ee9',
  welcomeImage: 'welcomeImage_b8f83ee9',
  links: 'links_b8f83ee9',
  columnfull: 'columnfull_b8f83ee9',
  columnleft: 'columnleft_b8f83ee9',
  columnright: 'columnright_b8f83ee9',
  row: 'row_b8f83ee9',
  submitButton: 'submitButton_b8f83ee9',
  inputtext: 'inputtext_b8f83ee9',
  peoplepicker: 'peoplepicker_b8f83ee9',
  imgTableIcon: 'imgTableIcon_b8f83ee9',
  interviewers: 'interviewers_b8f83ee9',
  custommodalpopup: 'custommodalpopup_b8f83ee9',
  'modal-body': 'modal-body_b8f83ee9',
  'modal-footer': 'modal-footer_b8f83ee9',
  'modal-title': 'modal-title_b8f83ee9',
  'modal-header': 'modal-header_b8f83ee9',
  imgcheckIcon: 'imgcheckIcon_b8f83ee9',
  homeIcon: 'homeIcon_b8f83ee9',
  informationIcon: 'informationIcon_b8f83ee9',
  floatright: 'floatright_b8f83ee9',
  theadicon: 'theadicon_b8f83ee9',
  requiredfield: 'requiredfield_b8f83ee9',
  'grid-container-element': 'grid-container-element_b8f83ee9',
  'grid-child-element': 'grid-child-element_b8f83ee9',
  header: 'header_b8f83ee9',
  maincontainer: 'maincontainer_b8f83ee9'
};

export default styles;
/* tslint:enable */