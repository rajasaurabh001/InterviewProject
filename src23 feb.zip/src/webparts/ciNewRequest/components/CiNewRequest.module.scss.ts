/* tslint:disable */
require("./CiNewRequest.module.css");
const styles = {
  ciNewRequest: 'ciNewRequest_7adeac3e',
  teams: 'teams_7adeac3e',
  welcome: 'welcome_7adeac3e',
  welcomeImage: 'welcomeImage_7adeac3e',
  links: 'links_7adeac3e',
  columnfull: 'columnfull_7adeac3e',
  columnleft: 'columnleft_7adeac3e',
  columnright: 'columnright_7adeac3e',
  row: 'row_7adeac3e',
  submitButton: 'submitButton_7adeac3e',
  inputtext: 'inputtext_7adeac3e',
  peoplepicker: 'peoplepicker_7adeac3e',
  custommodalpopup: 'custommodalpopup_7adeac3e',
  'modal-body': 'modal-body_7adeac3e',
  'modal-footer': 'modal-footer_7adeac3e',
  'modal-title': 'modal-title_7adeac3e',
  'modal-header': 'modal-header_7adeac3e',
  imgcheckIcon: 'imgcheckIcon_7adeac3e',
  requiredfield: 'requiredfield_7adeac3e',
  'grid-container-element': 'grid-container-element_7adeac3e',
  'grid-child-element': 'grid-child-element_7adeac3e',
  header: 'header_7adeac3e',
  maincontainer: 'maincontainer_7adeac3e',
  homeIcon: 'homeIcon_7adeac3e',
  CommentsWrapper: 'CommentsWrapper_7adeac3e'
};

export default styles;
/* tslint:enable */