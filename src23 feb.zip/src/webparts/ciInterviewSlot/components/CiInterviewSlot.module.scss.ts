/* tslint:disable */
require("./CiInterviewSlot.module.css");
const styles = {
  ciInterviewSlot: 'ciInterviewSlot_a2314558',
  teams: 'teams_a2314558',
  welcome: 'welcome_a2314558',
  welcomeImage: 'welcomeImage_a2314558',
  links: 'links_a2314558',
  columnfull: 'columnfull_a2314558',
  columnleft: 'columnleft_a2314558',
  columnright: 'columnright_a2314558',
  row: 'row_a2314558',
  submitButton: 'submitButton_a2314558',
  inputtext: 'inputtext_a2314558',
  imgTableIcon: 'imgTableIcon_a2314558',
  availableBlock: 'availableBlock_a2314558',
  timeSubmitBlock: 'timeSubmitBlock_a2314558',
  noBlock: 'noBlock_a2314558',
  notAvailable: 'notAvailable_a2314558',
  Available: 'Available_a2314558',
  interviewers: 'interviewers_a2314558',
  custommodalpopup: 'custommodalpopup_a2314558',
  'modal-body': 'modal-body_a2314558',
  'modal-footer': 'modal-footer_a2314558',
  'modal-title': 'modal-title_a2314558',
  'modal-header': 'modal-header_a2314558',
  imgcheckIcon: 'imgcheckIcon_a2314558',
  disabledSelectbox: 'disabledSelectbox_a2314558',
  homeIcon: 'homeIcon_a2314558',
  informationIcon: 'informationIcon_a2314558',
  theadicon: 'theadicon_a2314558',
  'grid-container-element': 'grid-container-element_a2314558',
  'grid-child-element': 'grid-child-element_a2314558',
  header: 'header_a2314558',
  maincontainer: 'maincontainer_a2314558',
  peoplepicker: 'peoplepicker_a2314558',
  requiredfield: 'requiredfield_a2314558'
};

export default styles;
/* tslint:enable */