/* tslint:disable */
require("./CiMainScreen.module.css");
const styles = {
  ciMainScreen: 'ciMainScreen_92334de4',
  teams: 'teams_92334de4',
  columnFilter: 'columnFilter_92334de4',
  columnMain: 'columnMain_92334de4',
  row: 'row_92334de4',
  btnSearch: 'btnSearch_92334de4',
  txtSearch: 'txtSearch_92334de4',
  filterTitle: 'filterTitle_92334de4',
  menuSection: 'menuSection_92334de4',
  Menu_Ul: 'Menu_Ul_92334de4',
  active: 'active_92334de4',
  newReq: 'newReq_92334de4',
  maincontainer: 'maincontainer_92334de4',
  menuHeading: 'menuHeading_92334de4',
  menuTitle: 'menuTitle_92334de4'
};

export default styles;
/* tslint:enable */