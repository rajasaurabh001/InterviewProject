/* tslint:disable */
require("./CiCandidateScreen.module.css");
const styles = {
  ciCandidateScreen: 'ciCandidateScreen_175f6269',
  teams: 'teams_175f6269',
  welcome: 'welcome_175f6269',
  welcomeImage: 'welcomeImage_175f6269',
  links: 'links_175f6269',
  columnfull: 'columnfull_175f6269',
  columnleft: 'columnleft_175f6269',
  columnright: 'columnright_175f6269',
  row: 'row_175f6269',
  submitButton: 'submitButton_175f6269',
  submitAssign: 'submitAssign_175f6269',
  inputtext: 'inputtext_175f6269',
  selecttext: 'selecttext_175f6269',
  newmanagertextbox: 'newmanagertextbox_175f6269',
  peoplepicker: 'peoplepicker_175f6269',
  imgTableIcon: 'imgTableIcon_175f6269',
  interviewers: 'interviewers_175f6269',
  custommodalpopup: 'custommodalpopup_175f6269',
  'modal-body': 'modal-body_175f6269',
  'modal-footer': 'modal-footer_175f6269',
  'modal-title': 'modal-title_175f6269',
  'modal-header': 'modal-header_175f6269',
  imgcheckIcon: 'imgcheckIcon_175f6269',
  homeIcon: 'homeIcon_175f6269',
  informationIcon: 'informationIcon_175f6269',
  floatright: 'floatright_175f6269',
  theadicon: 'theadicon_175f6269',
  requiredfield: 'requiredfield_175f6269',
  'grid-container-element': 'grid-container-element_175f6269',
  'grid-child-element': 'grid-child-element_175f6269',
  header: 'header_175f6269',
  maincontainer: 'maincontainer_175f6269',
  AssignMsg: 'AssignMsg_175f6269',
  pageheader: 'pageheader_175f6269'
};

export default styles;
/* tslint:enable */