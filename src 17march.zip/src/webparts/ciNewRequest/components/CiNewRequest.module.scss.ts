/* tslint:disable */
require("./CiNewRequest.module.css");
const styles = {
  ciNewRequest: 'ciNewRequest_bd7952fb',
  teams: 'teams_bd7952fb',
  welcome: 'welcome_bd7952fb',
  welcomeImage: 'welcomeImage_bd7952fb',
  links: 'links_bd7952fb',
  columnfull: 'columnfull_bd7952fb',
  columnleft: 'columnleft_bd7952fb',
  columnright: 'columnright_bd7952fb',
  row: 'row_bd7952fb',
  submitButton: 'submitButton_bd7952fb',
  inputtext: 'inputtext_bd7952fb',
  notetextarea: 'notetextarea_bd7952fb',
  selecttext: 'selecttext_bd7952fb',
  newmanagertextbox: 'newmanagertextbox_bd7952fb',
  peoplepicker: 'peoplepicker_bd7952fb',
  custommodalpopup: 'custommodalpopup_bd7952fb',
  'modal-body': 'modal-body_bd7952fb',
  'modal-footer': 'modal-footer_bd7952fb',
  'modal-title': 'modal-title_bd7952fb',
  'modal-header': 'modal-header_bd7952fb',
  imgcheckIcon: 'imgcheckIcon_bd7952fb',
  requiredfield: 'requiredfield_bd7952fb',
  'grid-container-element': 'grid-container-element_bd7952fb',
  'grid-child-element': 'grid-child-element_bd7952fb',
  header: 'header_bd7952fb',
  maincontainer: 'maincontainer_bd7952fb',
  homeIcon: 'homeIcon_bd7952fb',
  CommentsWrapper: 'CommentsWrapper_bd7952fb',
  disabledSelectbox: 'disabledSelectbox_bd7952fb',
  display: 'display_bd7952fb',
  imgTableIcon: 'imgTableIcon_bd7952fb',
  informationIcon: 'informationIcon_bd7952fb',
  theadicon: 'theadicon_bd7952fb',
  interviewers: 'interviewers_bd7952fb'
};

export default styles;
/* tslint:enable */