/* tslint:disable */
require("./CiMainScreen.module.css");
const styles = {
  ciMainScreen: 'ciMainScreen_a4ceadc2',
  teams: 'teams_a4ceadc2',
  columnFilter: 'columnFilter_a4ceadc2',
  columnMain: 'columnMain_a4ceadc2',
  row: 'row_a4ceadc2',
  btnSearch: 'btnSearch_a4ceadc2',
  txtSearch: 'txtSearch_a4ceadc2',
  filterTitle: 'filterTitle_a4ceadc2',
  menuSection: 'menuSection_a4ceadc2',
  Menu_Ul: 'Menu_Ul_a4ceadc2',
  active: 'active_a4ceadc2',
  newReq: 'newReq_a4ceadc2',
  maincontainer: 'maincontainer_a4ceadc2',
  menuHeading: 'menuHeading_a4ceadc2',
  menuTitle: 'menuTitle_a4ceadc2'
};

export default styles;
/* tslint:enable */