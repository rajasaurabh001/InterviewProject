/* tslint:disable */
require("./CiInterviewSlot.module.css");
const styles = {
  ciInterviewSlot: 'ciInterviewSlot_5e790141',
  teams: 'teams_5e790141',
  welcome: 'welcome_5e790141',
  welcomeImage: 'welcomeImage_5e790141',
  links: 'links_5e790141',
  columnfull: 'columnfull_5e790141',
  columnleft: 'columnleft_5e790141',
  columnright: 'columnright_5e790141',
  row: 'row_5e790141',
  submitButton: 'submitButton_5e790141',
  inputtext: 'inputtext_5e790141',
  selecttext: 'selecttext_5e790141',
  newmanagertextbox: 'newmanagertextbox_5e790141',
  imgTableIcon: 'imgTableIcon_5e790141',
  interviewers: 'interviewers_5e790141',
  availableBlock: 'availableBlock_5e790141',
  timeSubmitBlock: 'timeSubmitBlock_5e790141',
  noBlock: 'noBlock_5e790141',
  notAvailable: 'notAvailable_5e790141',
  Available: 'Available_5e790141',
  custommodalpopup: 'custommodalpopup_5e790141',
  'modal-body': 'modal-body_5e790141',
  'modal-footer': 'modal-footer_5e790141',
  'modal-title': 'modal-title_5e790141',
  'modal-header': 'modal-header_5e790141',
  imgcheckIcon: 'imgcheckIcon_5e790141',
  disabledSelectbox: 'disabledSelectbox_5e790141',
  homeIcon: 'homeIcon_5e790141',
  informationIcon: 'informationIcon_5e790141',
  theadicon: 'theadicon_5e790141',
  'grid-container-element': 'grid-container-element_5e790141',
  'grid-child-element': 'grid-child-element_5e790141',
  header: 'header_5e790141',
  maincontainer: 'maincontainer_5e790141',
  peoplepicker: 'peoplepicker_5e790141',
  requiredfield: 'requiredfield_5e790141'
};

export default styles;
/* tslint:enable */