/* tslint:disable */
require("./CiMainScreen.module.css");
const styles = {
  ciMainScreen: 'ciMainScreen_5e118277',
  teams: 'teams_5e118277',
  welcome: 'welcome_5e118277',
  welcomeImage: 'welcomeImage_5e118277',
  links: 'links_5e118277',
  columnFilter: 'columnFilter_5e118277',
  columnMain: 'columnMain_5e118277',
  row: 'row_5e118277',
  btnSearch: 'btnSearch_5e118277',
  txtSearch: 'txtSearch_5e118277',
  filterTitle: 'filterTitle_5e118277',
  menuSection: 'menuSection_5e118277',
  Menu_Ul: 'Menu_Ul_5e118277',
  active: 'active_5e118277',
  newReq: 'newReq_5e118277'
};

export default styles;
/* tslint:enable */