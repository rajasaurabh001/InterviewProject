/* tslint:disable */
require("./CiInterviewSlot.module.css");
const styles = {
  ciInterviewSlot: 'ciInterviewSlot_06796843',
  teams: 'teams_06796843',
  welcome: 'welcome_06796843',
  welcomeImage: 'welcomeImage_06796843',
  links: 'links_06796843',
  columnfull: 'columnfull_06796843',
  columnleft: 'columnleft_06796843',
  columnright: 'columnright_06796843',
  row: 'row_06796843',
  submitButton: 'submitButton_06796843',
  inputtext: 'inputtext_06796843',
  imgTableIcon: 'imgTableIcon_06796843',
  availableBlock: 'availableBlock_06796843',
  timeSubmitBlock: 'timeSubmitBlock_06796843',
  noBlock: 'noBlock_06796843',
  notAvailable: 'notAvailable_06796843',
  Available: 'Available_06796843',
  interviewers: 'interviewers_06796843',
  custommodalpopup: 'custommodalpopup_06796843',
  'modal-body': 'modal-body_06796843',
  'modal-footer': 'modal-footer_06796843',
  'modal-title': 'modal-title_06796843',
  'modal-header': 'modal-header_06796843',
  imgcheckIcon: 'imgcheckIcon_06796843',
  disabledSelectbox: 'disabledSelectbox_06796843',
  homeIcon: 'homeIcon_06796843'
};

export default styles;
/* tslint:enable */