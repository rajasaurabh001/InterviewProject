/* tslint:disable */
require("./CiCandidateScreen.module.css");
const styles = {
  ciCandidateScreen: 'ciCandidateScreen_133548f1',
  teams: 'teams_133548f1',
  welcome: 'welcome_133548f1',
  welcomeImage: 'welcomeImage_133548f1',
  links: 'links_133548f1',
  columnfull: 'columnfull_133548f1',
  columnleft: 'columnleft_133548f1',
  columnright: 'columnright_133548f1',
  row: 'row_133548f1',
  submitButton: 'submitButton_133548f1',
  inputtext: 'inputtext_133548f1',
  imgTableIcon: 'imgTableIcon_133548f1',
  interviewers: 'interviewers_133548f1',
  custommodalpopup: 'custommodalpopup_133548f1',
  'modal-body': 'modal-body_133548f1',
  'modal-footer': 'modal-footer_133548f1',
  'modal-title': 'modal-title_133548f1',
  'modal-header': 'modal-header_133548f1',
  imgcheckIcon: 'imgcheckIcon_133548f1',
  homeIcon: 'homeIcon_133548f1',
  informationIcon: 'informationIcon_133548f1',
  theadicon: 'theadicon_133548f1'
};

export default styles;
/* tslint:enable */