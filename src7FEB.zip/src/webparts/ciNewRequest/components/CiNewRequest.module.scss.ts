/* tslint:disable */
require("./CiNewRequest.module.css");
const styles = {
  ciNewRequest: 'ciNewRequest_fd2fb264',
  teams: 'teams_fd2fb264',
  welcome: 'welcome_fd2fb264',
  welcomeImage: 'welcomeImage_fd2fb264',
  links: 'links_fd2fb264',
  columnfull: 'columnfull_fd2fb264',
  columnleft: 'columnleft_fd2fb264',
  columnright: 'columnright_fd2fb264',
  row: 'row_fd2fb264',
  submitButton: 'submitButton_fd2fb264',
  inputtext: 'inputtext_fd2fb264',
  custommodalpopup: 'custommodalpopup_fd2fb264',
  'modal-body': 'modal-body_fd2fb264',
  'modal-footer': 'modal-footer_fd2fb264',
  'modal-title': 'modal-title_fd2fb264',
  'modal-header': 'modal-header_fd2fb264',
  imgcheckIcon: 'imgcheckIcon_fd2fb264',
  requiredfield: 'requiredfield_fd2fb264'
};

export default styles;
/* tslint:enable */