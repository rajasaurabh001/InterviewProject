/* tslint:disable */
require("./CiInterviewSlot.module.css");
const styles = {
  ciInterviewSlot: 'ciInterviewSlot_f22e9c25',
  teams: 'teams_f22e9c25',
  welcome: 'welcome_f22e9c25',
  welcomeImage: 'welcomeImage_f22e9c25',
  links: 'links_f22e9c25',
  columnfull: 'columnfull_f22e9c25',
  columnleft: 'columnleft_f22e9c25',
  columnright: 'columnright_f22e9c25',
  row: 'row_f22e9c25',
  submitButton: 'submitButton_f22e9c25',
  inputtext: 'inputtext_f22e9c25',
  imgTableIcon: 'imgTableIcon_f22e9c25',
  availableBlock: 'availableBlock_f22e9c25',
  timeSubmitBlock: 'timeSubmitBlock_f22e9c25',
  noBlock: 'noBlock_f22e9c25',
  notAvailable: 'notAvailable_f22e9c25',
  Available: 'Available_f22e9c25',
  interviewers: 'interviewers_f22e9c25',
  custommodalpopup: 'custommodalpopup_f22e9c25',
  'modal-body': 'modal-body_f22e9c25',
  'modal-footer': 'modal-footer_f22e9c25',
  'modal-title': 'modal-title_f22e9c25',
  'modal-header': 'modal-header_f22e9c25',
  imgcheckIcon: 'imgcheckIcon_f22e9c25',
  disabledSelectbox: 'disabledSelectbox_f22e9c25',
  homeIcon: 'homeIcon_f22e9c25',
  informationIcon: 'informationIcon_f22e9c25',
  theadicon: 'theadicon_f22e9c25',
  'grid-container-element': 'grid-container-element_f22e9c25',
  'grid-child-element': 'grid-child-element_f22e9c25',
  header: 'header_f22e9c25',
  maincontainer: 'maincontainer_f22e9c25',
  peoplepicker: 'peoplepicker_f22e9c25',
  requiredfield: 'requiredfield_f22e9c25'
};

export default styles;
/* tslint:enable */