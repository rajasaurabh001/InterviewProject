/* tslint:disable */
require("./CiCandidateScreen.module.css");
const styles = {
  ciCandidateScreen: 'ciCandidateScreen_d45c2e0f',
  teams: 'teams_d45c2e0f',
  welcome: 'welcome_d45c2e0f',
  welcomeImage: 'welcomeImage_d45c2e0f',
  links: 'links_d45c2e0f',
  columnfull: 'columnfull_d45c2e0f',
  columnleft: 'columnleft_d45c2e0f',
  columnright: 'columnright_d45c2e0f',
  row: 'row_d45c2e0f',
  submitButton: 'submitButton_d45c2e0f',
  inputtext: 'inputtext_d45c2e0f',
  peoplepicker: 'peoplepicker_d45c2e0f',
  imgTableIcon: 'imgTableIcon_d45c2e0f',
  interviewers: 'interviewers_d45c2e0f',
  custommodalpopup: 'custommodalpopup_d45c2e0f',
  'modal-body': 'modal-body_d45c2e0f',
  'modal-footer': 'modal-footer_d45c2e0f',
  'modal-title': 'modal-title_d45c2e0f',
  'modal-header': 'modal-header_d45c2e0f',
  imgcheckIcon: 'imgcheckIcon_d45c2e0f',
  homeIcon: 'homeIcon_d45c2e0f',
  informationIcon: 'informationIcon_d45c2e0f',
  floatright: 'floatright_d45c2e0f',
  theadicon: 'theadicon_d45c2e0f',
  requiredfield: 'requiredfield_d45c2e0f',
  'grid-container-element': 'grid-container-element_d45c2e0f',
  'grid-child-element': 'grid-child-element_d45c2e0f',
  header: 'header_d45c2e0f',
  maincontainer: 'maincontainer_d45c2e0f'
};

export default styles;
/* tslint:enable */