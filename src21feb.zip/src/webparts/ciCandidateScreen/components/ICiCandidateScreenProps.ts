export interface ICiCandidateScreenProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  siteUrl : string;
  user : any;
  context:any;
}
