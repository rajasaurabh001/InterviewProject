/* tslint:disable */
require("./CiMainScreen.module.css");
const styles = {
  ciMainScreen: 'ciMainScreen_1eca6a47',
  teams: 'teams_1eca6a47',
  welcome: 'welcome_1eca6a47',
  welcomeImage: 'welcomeImage_1eca6a47',
  links: 'links_1eca6a47',
  columnFilter: 'columnFilter_1eca6a47',
  columnMain: 'columnMain_1eca6a47',
  row: 'row_1eca6a47',
  btnSearch: 'btnSearch_1eca6a47',
  txtSearch: 'txtSearch_1eca6a47',
  filterTitle: 'filterTitle_1eca6a47',
  menuSection: 'menuSection_1eca6a47',
  Menu_Ul: 'Menu_Ul_1eca6a47',
  active: 'active_1eca6a47',
  newReq: 'newReq_1eca6a47',
  maincontainer: 'maincontainer_1eca6a47'
};

export default styles;
/* tslint:enable */