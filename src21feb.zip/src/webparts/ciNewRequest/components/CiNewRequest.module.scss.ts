/* tslint:disable */
require("./CiNewRequest.module.css");
const styles = {
  ciNewRequest: 'ciNewRequest_de56f1aa',
  teams: 'teams_de56f1aa',
  welcome: 'welcome_de56f1aa',
  welcomeImage: 'welcomeImage_de56f1aa',
  links: 'links_de56f1aa',
  columnfull: 'columnfull_de56f1aa',
  columnleft: 'columnleft_de56f1aa',
  columnright: 'columnright_de56f1aa',
  row: 'row_de56f1aa',
  submitButton: 'submitButton_de56f1aa',
  inputtext: 'inputtext_de56f1aa',
  peoplepicker: 'peoplepicker_de56f1aa',
  custommodalpopup: 'custommodalpopup_de56f1aa',
  'modal-body': 'modal-body_de56f1aa',
  'modal-footer': 'modal-footer_de56f1aa',
  'modal-title': 'modal-title_de56f1aa',
  'modal-header': 'modal-header_de56f1aa',
  imgcheckIcon: 'imgcheckIcon_de56f1aa',
  requiredfield: 'requiredfield_de56f1aa',
  'grid-container-element': 'grid-container-element_de56f1aa',
  'grid-child-element': 'grid-child-element_de56f1aa',
  header: 'header_de56f1aa',
  maincontainer: 'maincontainer_de56f1aa',
  homeIcon: 'homeIcon_de56f1aa',
  CommentsWrapper: 'CommentsWrapper_de56f1aa'
};

export default styles;
/* tslint:enable */