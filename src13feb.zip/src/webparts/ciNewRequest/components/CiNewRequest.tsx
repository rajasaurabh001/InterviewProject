import * as React from 'react';
import styles from './CiNewRequest.module.scss';
import { ICiNewRequestProps } from './ICiNewRequestProps';
import { escape } from '@microsoft/sp-lodash-subset';
import pnp, { Web, SearchQuery, SearchResults, ItemAddResult } from "sp-pnp-js";
import * as $ from 'jquery'; 
import { Modal, values } from 'office-ui-fabric-react';


export interface ICiNewRequestState {
  //rows: any;
 // RequestID:any;
  CandidateName:string;
  CandidateEmail:string;
  AdditionalDetails:string;
  JobTitle:string;
  Position:string;
  JobDetails:string;
  Status:string;
  isModalOpen:boolean;
  validationobject:any;
  isSubmmited:boolean;
  isValidated:boolean;
  modalmessage:String;
  Draftmessage:String;
  Submittedmessage:String;
  siteabsoluteurl:Web
};

export default class CiNewRequest extends React.Component<ICiNewRequestProps, ICiNewRequestState> {
  //update requisiton ID

  constructor(props:ICiNewRequestProps,state:ICiNewRequestState ){
    super(props);
    this.state ={
     // rows: [],
     // RequestID:"",
      CandidateName : "",
      CandidateEmail:"",
      AdditionalDetails:"",
      JobTitle:"",
      Position:"",
      JobDetails:"",
      Status:"",
      isModalOpen:false,
      isSubmmited:false,
      validationobject:{ 
        CandidateName:false,
        CandidateEmail:false,
        AdditionalDetails: false,
        JobTitle: false,
        Position:false,
        JobDetails: false,
       },
      siteabsoluteurl:new Web(this.props.siteUrl),
      isValidated:false ,
      modalmessage:"",
      Draftmessage:"This candidate has been added as draft.",
      Submittedmessage:"This request has been submitted to the team."

    };
    
  }
  public async componentDidMount(){
    this.getRequestDetail();
    $("[data-focuszone-id=FocusZone14]").first().css( "display", "none" );
    $("[data-automation-id=pageHeader]").hide()
    $('#CommentsWrapper').hide();
  }
   public getRequestDetail=async () =>{ 
    let queryParams = new URLSearchParams(window.location.search);
    let ID = parseInt(queryParams.get("Req")); 
 
    console.log(this.state);
    let web = new Web(this.props.siteUrl);
    let libDetails = await web.lists
    .getByTitle("Candidate Interview Info")
    .items.getById(ID).get().then((response) => {
      console.log(response);
      this.setState({
        //RequestID: response.ID,
        CandidateName: response.Title,
        CandidateEmail: response.CandidateEmail,
        AdditionalDetails: response.AdditionalDetails,
        JobTitle: response.JobTitle,
        Position: response.Position,
        JobDetails: response.JobDetails,
        Status: response.Status
       });
    });
  }

  private async updateRequisitionID(itemID){
    let updatedid=itemID;
    let web = new Web(this.props.siteUrl);
    let updatelibdetail =  web.lists
    .getByTitle("Candidate Interview Info")
    .items.getById(updatedid).update({
      RequisitionID: "REQ_"+updatedid,
    }).then((response: ItemAddResult) => {
      let message = (this.state.isSubmmited)?this.state.Submittedmessage:this.state.Draftmessage
      this.isModalOpen(message); 
      //window.location.href="https://irmyanmarcom.sharepoint.com/sites/temp-rujal/SitePages/Dashboard.aspx";
    });
  }
  //Add new request to the List
  private async addNewRequest(){
    // Object.entries(this.state.validationobject).forEach(key => {
    // console.log(key)
    // });
    console.log(this.state.validationobject)
    // const allTrue = Object.values(this.state.validationobject).every(
    //   value => value === true
    // );
    // this.setState({
    //   isValidated : allTrue,
    // })
 // if(false){
    let queryParams = new URLSearchParams(window.location.search);
    const ID = parseInt(queryParams.get("Req")); 
    let SubmittedDatetime  =new Date().toLocaleString("en-US", { year:"numeric", month:"short", day:"2-digit", hour:"2-digit", minute:"2-digit" });
    let libDetails = await this.state.siteabsoluteurl.lists.getByTitle("Candidate Interview Info").items;
  
    if(Number.isNaN(ID)){
        libDetails.add({
          Title: this.state.CandidateName,
          CandidateEmail: this.state.CandidateEmail,
          AdditionalDetails: this.state.AdditionalDetails,
          JobTitle: this.state.JobTitle,
          JobDetails: this.state.JobDetails,
          Comment:"Waiting for timeslot entry",
          Status:"Submitted",
          Submitted:SubmittedDatetime
      }).then(async (response: ItemAddResult) => {
        await this.updateRequisitionID(response.data.ID);
      }); 
    }else{
      libDetails.getById(ID).update({
          Title: this.state.CandidateName,
          CandidateEmail: this.state.CandidateEmail,
          AdditionalDetails: this.state.AdditionalDetails,
          JobTitle: this.state.JobTitle,
          JobDetails: this.state.JobDetails,
          Comment: "Waiting for timeslot entry",
          Status:"Submitted",
          Submitted:SubmittedDatetime
      })
      await this.isModalOpen(this.state.Submittedmessage);   
    }
  // }
  // else{
  //   console.log("in else block")
  // }
  }

  private async addDraftRequest(){
    let queryParams = new URLSearchParams(window.location.search);
    const ID = parseInt(queryParams.get("Req")); 
    let libDetails = await this.state.siteabsoluteurl.lists.getByTitle("Candidate Interview Info").items;
    if(Number.isNaN(ID)){
        libDetails.add({
          Title: this.state.CandidateName,
          CandidateEmail: this.state.CandidateEmail,
          AdditionalDetails: this.state.AdditionalDetails,
          JobTitle: this.state.JobTitle,
          JobDetails: this.state.JobDetails,
          Comment:"Request has been created by " + this.props.userDisplayName,
          Status:"Draft",
      }).then(async (response: ItemAddResult) => {
        await this.updateRequisitionID(response.data.ID);
      }); 
    }else{
      libDetails.getById(ID).update({
          Title: this.state.CandidateName,
          CandidateEmail: this.state.CandidateEmail,
          AdditionalDetails: this.state.AdditionalDetails,
          JobTitle: this.state.JobTitle,
          JobDetails: this.state.JobDetails,
      })
        await this.isModalOpen(this.state.Draftmessage); 
    }
  }

  public handleChange = () => async(event) => {
    
      const { name, value } = event.target;
      //const rowInfo = rows[idx];
      //rowInfo[name] = value;
    
  }

  public isModalOpen = async(message:any) => {
    this.setState({
      isModalOpen:true,
      modalmessage:message,
    });
  }
  public reload =() =>{
    // window.location.reload();
    const myTimeout = setTimeout(window.location.href="https://irmyanmarcom.sharepoint.com/sites/temp-rujal/SitePages/Dashboard.aspx", 2000);
  }
  public render(): React.ReactElement<ICiNewRequestProps> {
    const {
      description,
      isDarkTheme,
      environmentMessage,
      hasTeamsContext,
      userDisplayName
    } = this.props;

    return (      
        <div className={styles.maincontainer}>
          <div className={styles['grid-container-element']}>
            <div className={styles['grid-child-element']}>
              <h2 className={styles.header}>Create New Interview Request</h2>
            </div>
            <div className={styles['grid-child-element']}> <img src={require('../assets/homeicon.png')} className={styles.homeIcon}  onClick={this.reload}/></div>
          </div>
          
          <Modal isOpen={this.state.isModalOpen} isBlocking={false} className={styles.custommodalpopup} >
            <div className='modal-dialog modal-help' style={{width: '500px', height: '170px',}}>
              <div className='modal-content'>
                {/* <div className={styles['modal-header']}>
                  <h3 className='modal-title'></h3>
                </div> */}
                <div className={styles['modal-body']}><span ><h2 className='modalmessage'>{this.state.modalmessage}</h2></span>
                <div><img src={require('../assets/accept.png')} className={styles.imgcheckIcon}/></div></div>
                <div className={styles['modal-footer']} >
                  <button type="button" className={styles.submitButton} onClick={()=>{this.reload()}} style={{float:'right',margin:'10px' ,width:'65px'}}>OK</button>
                </div>
              </div>
            </div>          
          </Modal>
                

          {/* <form action="" onSubmit={() =>this.addNewRequest()}> */}
          <div className={styles.row}>
            <div className={styles.columnfull}>
              <span>Candidate Details</span>               
            </div>
          </div>
          <div className={styles.row}>
            <div className={styles.columnleft}>
              <span><span className={styles.requiredfield}>* </span>Name</span>               
            </div>
            <div className={styles.columnright}>
            <input type="text" 
              className={styles.inputtext}   
              required={true}
              onChange={(e)=>{
                this.setState({
                  CandidateName : e.target.value,
                 // validationobject:{CandidateName: (e.target.value.length > 0) ? true:false}
                });
              }} 
             value={this.state.CandidateName}/>  
             {/* {this.state.validationobject.CandidateName == false?<div className={styles.row}><span className={styles.requiredfield}>Require field can be blank!</span></div>:null}               */}
            </div>
          </div>
          <div className={styles.row}>
            <div className={styles.columnleft}>
              <span><span className={styles.requiredfield}>* </span>Email</span>                
            </div>
            <div className={styles.columnright}>   
            <input type="email" 
              required={true}
              className={styles.inputtext}  
              onChange={(e)=>{
                this.setState({
                  CandidateEmail : e.target.value,
                 // validationobject:({CandidateEmail: (e.target.value.length > 0) ? true:false})
                });
              }}   
              value={this.state.CandidateEmail}/>  
              {/* {this.state.validationobject.CandidateEmail == false?<div className={styles.row}><span className={styles.requiredfield}>Require field can be blank!</span></div>:null}             */}
            </div>
          </div>
          <div className={styles.row}>
            <div className={styles.columnleft}>
              <span><span className={styles.requiredfield}>* </span>Candidate ID</span>                
            </div>
            <div className={styles.columnright}>      
            <input type="text" 
              required={true}
              className={styles.inputtext} 
               onChange={(e)=>{
                this.setState({
                  AdditionalDetails : e.target.value,
                 // validationobject:{AdditionalDetails: (e.target.value.length > 0) ? true:false}
                });
              }}   
              value={this.state.AdditionalDetails}/>   
            {/* {this.state.validationobject.AdditionalDetails == false?<div className={styles.row}><span className={styles.requiredfield}>Require field can be blank!</span></div>:null}          */}
            </div>
          </div>

          <div className={styles.row}>
            <div className={styles.columnfull}>
              <span>Position Details</span>               
            </div>
          </div>
          <div className={styles.row}>
            <div className={styles.columnleft}>
              <span><span className={styles.requiredfield}>* </span>Job Title</span>                
            </div>
            <div className={styles.columnright}>  
            <input type="text" 
              required={true}
              className={styles.inputtext}  
              onChange={(e)=>{
                this.setState({
                  JobTitle : e.target.value,
                 // validationobject:{JobTitle: (e.target.value.length > 0) ? true:false}
                });
              }}  
              value={this.state.JobTitle}/>  
              {/* {this.state.validationobject.JobTitle == false?<div className={styles.row}><span className={styles.requiredfield}>Require field can be blank!</span></div>:null}                             */}
            </div>
          </div>
          {/* <div className={styles.row}>
            <div className={styles.columnleft}>
              <span>Position</span>                
            </div>
            <div className={styles.columnright}>    
            <input type="text" className={styles.inputtext} onChange={(e)=>{this.setState({Position : e.target.value});}} value={this.state.Position}/>                          
            </div>
          </div> */}
          <div className={styles.row}>
            <div className={styles.columnleft}>
              <span><span className={styles.requiredfield}>* </span>Requisition ID</span>                
            </div>
            <div className={styles.columnright}>    
            <input type="text" 
                required={true}
                name="JobDetails" 
                className={styles.inputtext} 
                onChange={(e)=>{
                  this.setState({
                    JobDetails : e.target.value,
                  // validationobject:{JobDetails: (e.target.value.length > 0) ? true:false}
                  });
                }}   
              value={this.state.JobDetails}/>  
             {/* {this.state.validationobject.JobDetails == false?<div className={styles.row}><span className={styles.requiredfield}>Require field can be blank!</span></div>:null}             */}
            </div>
          </div>
          <div className={styles.row}>
            <div className={styles.columnfull} style={{backgroundColor: "white"}}>                          
            </div>
          </div>

          {(this.state.Status == "Draft" || this.state.Status == "")?
          <div className={styles.row}>
            <div className={styles.columnfull} style={{backgroundColor: "white", marginLeft: '40%'}}>   
            <button type="button" className={styles.submitButton} onClick = {() =>this.addDraftRequest()}>Draft</button>  
            <button type="submit" className={styles.submitButton} onClick ={() =>this.addNewRequest()}>Submit</button>  
            <button className={styles.submitButton} name="Cancel" onClick={() => this.reload()}>Cancel</button>         
            </div>
          </div>
           :null}
           {/* </form> */}
        </div> 
      
    );
  }
}
