/* tslint:disable */
require("./CiNewRequest.module.css");
const styles = {
  ciNewRequest: 'ciNewRequest_a9138922',
  teams: 'teams_a9138922',
  welcome: 'welcome_a9138922',
  welcomeImage: 'welcomeImage_a9138922',
  links: 'links_a9138922',
  columnfull: 'columnfull_a9138922',
  columnleft: 'columnleft_a9138922',
  columnright: 'columnright_a9138922',
  row: 'row_a9138922',
  submitButton: 'submitButton_a9138922',
  inputtext: 'inputtext_a9138922',
  custommodalpopup: 'custommodalpopup_a9138922',
  'modal-body': 'modal-body_a9138922',
  'modal-footer': 'modal-footer_a9138922',
  'modal-title': 'modal-title_a9138922',
  'modal-header': 'modal-header_a9138922',
  imgcheckIcon: 'imgcheckIcon_a9138922',
  requiredfield: 'requiredfield_a9138922',
  'grid-container-element': 'grid-container-element_a9138922',
  'grid-child-element': 'grid-child-element_a9138922',
  header: 'header_a9138922',
  maincontainer: 'maincontainer_a9138922',
  homeIcon: 'homeIcon_a9138922',
  CommentsWrapper: 'CommentsWrapper_a9138922'
};

export default styles;
/* tslint:enable */