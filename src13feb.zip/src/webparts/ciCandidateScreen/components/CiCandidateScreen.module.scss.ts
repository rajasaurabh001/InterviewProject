/* tslint:disable */
require("./CiCandidateScreen.module.css");
const styles = {
  ciCandidateScreen: 'ciCandidateScreen_1a7370cb',
  teams: 'teams_1a7370cb',
  welcome: 'welcome_1a7370cb',
  welcomeImage: 'welcomeImage_1a7370cb',
  links: 'links_1a7370cb',
  columnfull: 'columnfull_1a7370cb',
  columnleft: 'columnleft_1a7370cb',
  columnright: 'columnright_1a7370cb',
  row: 'row_1a7370cb',
  submitButton: 'submitButton_1a7370cb',
  inputtext: 'inputtext_1a7370cb',
  imgTableIcon: 'imgTableIcon_1a7370cb',
  interviewers: 'interviewers_1a7370cb',
  custommodalpopup: 'custommodalpopup_1a7370cb',
  'modal-body': 'modal-body_1a7370cb',
  'modal-footer': 'modal-footer_1a7370cb',
  'modal-title': 'modal-title_1a7370cb',
  'modal-header': 'modal-header_1a7370cb',
  imgcheckIcon: 'imgcheckIcon_1a7370cb',
  homeIcon: 'homeIcon_1a7370cb',
  informationIcon: 'informationIcon_1a7370cb',
  theadicon: 'theadicon_1a7370cb',
  requiredfield: 'requiredfield_1a7370cb',
  'grid-container-element': 'grid-container-element_1a7370cb',
  'grid-child-element': 'grid-child-element_1a7370cb',
  header: 'header_1a7370cb',
  maincontainer: 'maincontainer_1a7370cb'
};

export default styles;
/* tslint:enable */