/* tslint:disable */
require("./CiInterviewSlot.module.css");
const styles = {
  ciInterviewSlot: 'ciInterviewSlot_62425f6d',
  teams: 'teams_62425f6d',
  welcome: 'welcome_62425f6d',
  welcomeImage: 'welcomeImage_62425f6d',
  links: 'links_62425f6d',
  columnfull: 'columnfull_62425f6d',
  columnleft: 'columnleft_62425f6d',
  columnright: 'columnright_62425f6d',
  row: 'row_62425f6d',
  submitButton: 'submitButton_62425f6d',
  inputtext: 'inputtext_62425f6d',
  imgTableIcon: 'imgTableIcon_62425f6d',
  availableBlock: 'availableBlock_62425f6d',
  timeSubmitBlock: 'timeSubmitBlock_62425f6d',
  noBlock: 'noBlock_62425f6d',
  notAvailable: 'notAvailable_62425f6d',
  Available: 'Available_62425f6d',
  interviewers: 'interviewers_62425f6d',
  custommodalpopup: 'custommodalpopup_62425f6d',
  'modal-body': 'modal-body_62425f6d',
  'modal-footer': 'modal-footer_62425f6d',
  'modal-title': 'modal-title_62425f6d',
  'modal-header': 'modal-header_62425f6d',
  imgcheckIcon: 'imgcheckIcon_62425f6d',
  disabledSelectbox: 'disabledSelectbox_62425f6d',
  homeIcon: 'homeIcon_62425f6d',
  informationIcon: 'informationIcon_62425f6d',
  theadicon: 'theadicon_62425f6d',
  'grid-container-element': 'grid-container-element_62425f6d',
  'grid-child-element': 'grid-child-element_62425f6d',
  header: 'header_62425f6d',
  maincontainer: 'maincontainer_62425f6d'
};

export default styles;
/* tslint:enable */